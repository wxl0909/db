package com.lanou.manage.service;

import com.lanou.manage.bean.Users;

import java.util.List;

public interface UsersService {
    public List<Users> userList();
    public int findUser(Integer account);
    public int addUser(Users users);
}

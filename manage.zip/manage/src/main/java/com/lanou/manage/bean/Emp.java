package com.lanou.manage.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Emp {
    private Integer eid;
    private String ename;
    private String birth;
}

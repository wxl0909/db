package com.lanou.manage.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Users {
    private Integer id;
    private String telphone;
    private String account;
    private String password;
    private Integer eid;
}

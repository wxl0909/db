package com.lanou.manage.service.impl;

import com.lanou.manage.mapper.UsersMapper;
import com.lanou.manage.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServiceImpl implements UsersService {
    @Autowired
    private UsersMapper usersMapper;
}
